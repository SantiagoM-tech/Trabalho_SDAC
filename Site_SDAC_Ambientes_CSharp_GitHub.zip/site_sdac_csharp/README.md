# Site SDAC — Ambientes de desenvolvimento em C#

Este site foi criado para uma apresentação interativa sobre Visual Studio, Visual Studio Code e JetBrains Rider.

## Ficheiros
- `index.html` — conteúdo e estrutura do site.
- `style.css` — aspeto visual e adaptação a telemóveis.
- `script.js` — cartões interativos, cópia de código e quiz.
- `assets/` — ilustrações SVG dos três ambientes.

## Como abrir no computador
Abre o ficheiro `index.html` num navegador (Chrome, Edge ou Firefox).

## Como publicar gratuitamente com GitHub Pages
1. Entra em https://github.com e inicia sessão.
2. Cria um repositório novo, por exemplo `sdac-csharp`.
3. Mantém o repositório como **Public**.
4. Carrega todos os ficheiros e a pasta `assets` para a raiz do repositório.
5. No repositório, abre **Settings → Pages**.
6. Em **Build and deployment**, escolhe **Deploy from a branch**.
7. Seleciona a branch `main` e a pasta `/ (root)`, depois carrega em **Save**.
8. Aguarda a publicação. O endereço ficará normalmente no formato:
   `https://TEU-NOME.github.io/sdac-csharp/`

Importante: não carregues apenas o ZIP. Extrai primeiro o conteúdo e envia `index.html`, `style.css`, `script.js` e a pasta `assets`.

## Personalização
No `index.html`, procura `Nomes do grupo` se quiseres acrescentar os nomes na capa. Podes também editar a turma e o ano letivo.
As imagens SVG incluídas são ilustrações originais das interfaces, não capturas de ecrã oficiais.
